📋 Complete Project Checklist
Here's what we're building:
 ✅ Project structure created
 ✅ Database loaded
 ✅ Export methodology understood
 🔲 Write all 20 SQL queries (Files 1-5)
 🔲 Export all key results to CSV
 🔲 Create 3-5 visualizations
 🔲 Write comprehensive README with findings
 🔲 Push to GitHub
 🔲 Add to your resume/portfolio
Let's do this systematically.

---

# TLDR;

## Goals:
1. make business logic (status thresholds, focus filter) *visibly* separate from the join/aggregation mechanics.

## Key Concepts:
💡 **Nerdy mental model:**
    + psql is “the remote control,
    + postgres is “the TV.
    = You can have the remote without having the TV plugged in.

```bash
# Start PostgreSQL server
brew services start postgresql@14

# Check if PostgreSQL is running
pg_isready

# If either fails, get the service status + logs
brew services | grep -i postgresql

# Option B: create your own database (then your plain psql works)
createdb <database_name>

# OR
createdb -h /tmp -p 5432 <database_name>

# Or (more explicit / reliable):
psql -d postgres -c "create database <database_name>;"
```

```bash
# connect to northwind database
psql -d northwind   # (terminal should now start with "northwind=#")

# list tables
\dt

# show sample data from orders table
SELECT * FROM orders LIMIT 5;

# quit
\q
```

```sql
> psql commands:
-- the "pager" ":"
-- enable expanded display = `\x auto`
-- disable pager = `\pset pager off`
-- widen columns = `\pset columns 200`
```

**ATTN: CASTING DATA TYPES:**
>- Going forward — whenever you write ROUND(), immediately add ::numeric and you'll never hit this error again.

-- PostgreSQL ROUND() with 2 arguments ONLY accepts numeric
-- These types need ::numeric cast:
- double precision  → needs ::numeric
- interval          → needs ::numeric
- float             → needs ::numeric

-- Safe rule: when using ROUND(x, n), always cast:
ROUND(your_expression::numeric, 2)

---
> PROJECT:
    > Log the process, refer to other files created or logs made (i.e. git log) to learn more about a subprocess

---

># 1. Setting up the project
- I use material icon theme for my editor in Windsurf.

```bash
# Check PostgreSQL versions
psql --version

# shows the path to the psql executable
which psql

# checks whether the actual database server executable exists:
postgres --version

# shows the path to the postgres executable
which postgres

# Is a Postgres server running right now?
pg_isready
```
> result: /tmp:5432 - no response

```bash
#
psql -c "select version();"

# Start PostgreSQL server
# pg_ctl -D /usr/local/var/postgres start

# macOS/Homebrew-specific: did you install it via brew?
brew list --versions postgresql@16 postgresql@15 postgresql

# Check if PostgreSQL is listening on port 5432
lsof -nP -iTCP:5432 -sTCP:LISTEN

# PostgreSQL service status and logs
brew services info postgresql@14
brew services logs postgresql@14

# Option A: connect to the default postgres database (works on most installs)
psql -d postgres -c "select version();"

# Option B: create your own database named b (then your plain psql works)
createdb -h /tmp -p 5432 b

# Option C: connect to your user database (may not exist yet)
psql -c "select version();"
```

2. Setup Northwind database

## **Setup Commands (Copy/Paste)** 🚀

```bash
# open terminal
ctrl+`

# using terminal:
# Navigate to projects directory
cd <your project directory>

# Create project structure
mkdir analytics-sql-northstar or <whatever you want>
cd analytics-sql-northstar
mkdir -p database sql results/visualizations docs

# Copy database files
cp /Users/b/data/projects/northwind_psql/northwind.sql database/
# or (use relative path)
cp northwind_psql/northwind.sql database/

# Initialize git
git init

# Create essential files
touch README.md
touch database/setup_instructions.md
touch .gitignore

# You're ready to start writing queries!
```

```bash
# Clone the official Northwind PostgreSQL repository
git clone https://github.com/pthom/northwind_psql.git

# OR download directly:
# Go to: https://github.com/pthom/northwind_psql
# Click green "Code" button → Download ZIP

# create the database
createdb northwind

# from the northwind_psql directory, run:
cd northwind_psql
psql -d northwind -f northwind.sql
```

> You should see a wall of ALTER TABLE & INSERT statements fly by.

---

```bash
# Copy database files
cp /Users/b/data/projects/northwind_psql/northwind.sql database/
```

```bash
# List databases
psql -l

# output
b@Brandons-iMac analytics-sql-northstar % psql -l
                         List of databases
   Name    | Owner | Encoding | Collate | Ctype | Access privileges
-----------+-------+----------+---------+-------+-------------------
 b         | b     | UTF8     | C       | C     |
 postgres  | b     | UTF8     | C       | C     |
 template0 | b     | UTF8     | C       | C     | =c/b             +
           |       |          |         |       | b=CTc/b
 template1 | b     | UTF8     | C       | C     | =c/b             +
           |       |          |         |       | b=CTc/b
(4 rows)
```

drop database b;
create database northstar;

```bash
# run the sales query
psql -d northwind -f sql/02-sales.sql
```

```bash
# run the sales query and save to file
psql -d northwind -f sql/02-sales.sql > sales_report.txt
```

There are 3 main ways to run SQL queries:
1. Interactive mode (psql -d database -f file.sql)
2. target mode (psql -d northwind -c "SELECT count(*) FROM orders;")
3. Batch mode (psql -d database -f file.sql > output.txt)
4. Programmatic mode (using a programming language like Python)

---

```bash
# Run all queries and save results
psql -U postgres -d northwind -f sql/01_customer_analysis.sql > results/customer_analysis_output.txt

# Or run individual queries and export as CSV
psql -U postgres -d northwind -c "SELECT ..." --csv > results/top_customers.csv
```

> test export

```bash
cd /Users/b/data/projects/analytics-sql-northstar

# Run this complete command
mk dir outputs
# mkdir -p outputs && \

psql -d northwind -c "
SELECT
    c.customer_id,
    c.company_name,
    COUNT(DISTINCT o.order_id) as orders,
    ROUND(SUM(od.unit_price * od.quantity)::numeric, 2) as revenue
FROM customers c
JOIN orders o ON c.customer_id = o.customer_id
JOIN order_details od ON o.order_id = od.order_id
GROUP BY c.customer_id, c.company_name
ORDER BY revenue DESC
LIMIT 10;
" --csv > outputs/test_top_customers.csv

# ALT SAFER VERSION
set -e
mkdir -p outputs
psql -d northwind -c "..." --csv > outputs/test_top_customers.csv

# Check if it worked
cat outputs/test_top_customers.csv
```

> Going forward — whenever you write ROUND(), immediately add ::numeric and you'll never hit this error again.

> fixed customers, sales

<!-- > ⚠️ **Data Note:** `days_since_purchase` metrics are not meaningful
> as the database ends in May 1998 and comparisons to current date are not possible. -->

---
> git commands to get git going

```bash
git branch
git checkout -b main 2>/dev/null || git checkout main
```

> SSH (recommended if you’ve set up keys)
```bash
git remote add origin git@github.com:<YOUR_GITHUB_USERNAME>/<REPO_NAME>.git
```
>HTTPS
git remote add origin https://github.com/<YOUR_GITHUB_USERNAME>/<REPO_NAME>.git

>Then, verify
```bash
git remote -v
```

> Finally, first push so future pushes are easier (with just `git push`)

```bash
git push -u origin main
```

---

> b@Brandons-iMac analytics-northwind % gh repo create cat-cols/analytics-northwind --public --source=. --remote=origin
✓ Created repository cat-cols/analytics-northwind on github.com
  https://github.com/cat-cols/analytics-northwind
X Unable to add remote "origin"

Nice — repo created ✅. The only hiccup is `gh` couldn’t set `origin` (because you *already* have an `origin` remote). No problem; we’ll just point `origin` at the repo you just created and push.

## 1) Set `origin` to the newly created repo (SSH)

```bash
git remote set-url origin git@github.com:cat-cols/analytics-northwind.git
```

Verify:

```bash
git remote -v
```

## 2) Push

```bash
git push -u origin main
```

---

### If push fails because you have no commits yet

Check:

```bash
git log --oneline --max-count=3
```

If it says there are no commits, do:

```bash
git add -A
git commit -m "Initial commit: Northwind analytics project"
git push -u origin main
```

---

### Optional cleanup: why `gh` complained

It tried to **add** a remote named `origin`, but one already exists. If you ever want `gh` to manage it automatically, you can remove and re-add:

```bash
git remote remove origin
git remote add origin git@github.com:cat-cols/analytics-northwind.git
```

But you don’t need that — `set-url` is the cleanest fix.

Run the `set-url` + `push` and you should be live.

---

# scan for secrets/passwords/keys

git grep -nEi "api[_-]?key|secret|token|password|snowflake|account|private key|BEGIN RSA|BEGIN OPENSSH" -- .

---
---

> Create scripts folder
```bash
# Navigate to your project
cd /Users/b/data/projects/analytics-northwind

# Create scripts directory if it doesn't exist
mkdir -p scripts

# Create the fixed export script
nano scripts/export_all_results.sh
# Paste the corrected script above
# Save: Ctrl+X → Y → Enter

# Make it executable
chmod +x scripts/export_all_results.sh

# Test it
./scripts/export_all_results.sh
```

