## 🎉 Queries Are Working! Let's Fix That Error

Great news - queries 6, 7, 8, and 9 all ran perfectly! You have real data now. Query 10 just needs a small type cast fix.

---

## ✅ **Quick Observations on Your Data**

Before fixing, notice some interesting things in your results:

**Monthly Sales:**
- 1998-05 only has 14 orders (database cuts off mid-May 1998 - that's why)
- Clear growth trend through 1997

**YoY Growth:**
- 1997 shows 196% growth vs 1996 ✅
- 1998 shows -28% ⚠️ (but 1998 data is incomplete - only through May!)
- **This is an important analytical note for your README**

**Day of Week:**
- Only weekdays! (Northwind is a B2B company - no weekend orders)
- Friday generates highest average order value

---

## 🔧 **Fix Query 10 - Type Cast Error**

**The Problem:**

`PERCENTILE_CONT` returns `double precision` but `ROUND()` in PostgreSQL needs `numeric` type. Simple fix - add `::numeric` cast.

**Open your file:**

```bash
nano /Users/b/data/projects/analytics-northwind/sql/02-sales.sql
```

**Find this line:**
```sql
ROUND(PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY order_date - previous_order_date), 1) as median_days_between_orders
```

**Replace with:**
```sql
ROUND(PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY order_date - previous_order_date)::numeric, 1) as median_days_between_orders
```

**The fix is just adding `::numeric` after the closing parenthesis of `PERCENTILE_CONT`.**

---

## 🔧 **Fix All 4 ROUND() Lines in Query 10**

Replace the entire Query 10 with this corrected version:

```sql
-- ========================================
-- QUERY 10: Average Order Frequency
-- ========================================
-- Business Question: How frequently do customers place orders?
-- Use Case: Customer engagement metrics, retention strategies
-- Expected Output: Average days between orders per customer

WITH customer_orders AS (
    SELECT
        customer_id,
        order_date,
        LAG(order_date) OVER (PARTITION BY customer_id ORDER BY order_date) as previous_order_date
    FROM orders
)
SELECT
    ROUND(AVG(order_date - previous_order_date)::numeric, 1) as avg_days_between_orders,
    ROUND(MIN(order_date - previous_order_date)::numeric, 1) as min_days_between_orders,
    ROUND(MAX(order_date - previous_order_date)::numeric, 1) as max_days_between_orders,
    ROUND(PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY order_date - previous_order_date)::numeric, 1) as median_days_between_orders
FROM customer_orders
WHERE previous_order_date IS NOT NULL;

-- Expected Result: ~40-50 days average between customer orders
```

**The fix:** Added `::numeric` after every expression inside `ROUND()`.

---

## 🧪 **Test the Fix**

```bash
# Run just query 10 to test
psql -d northwind -c "
WITH customer_orders AS (
    SELECT
        customer_id,
        order_date,
        LAG(order_date) OVER (PARTITION BY customer_id ORDER BY order_date) as previous_order_date
    FROM orders
)
SELECT
    ROUND(AVG(order_date - previous_order_date)::numeric, 1) as avg_days_between_orders,
    ROUND(MIN(order_date - previous_order_date)::numeric, 1) as min_days_between_orders,
    ROUND(MAX(order_date - previous_order_date)::numeric, 1) as max_days_between_orders,
    ROUND(PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY order_date - previous_order_date)::numeric, 1) as median_days_between_orders
FROM customer_orders
WHERE previous_order_date IS NOT NULL;
"
```

**Expected output:**
```
 avg_days_between_orders | min_days_between_orders | max_days_between_orders | median_days_between_orders 
-------------------------+-------------------------+-------------------------+----------------------------
                    XX.X |                     X.X |                   XXX.X |                       XX.X
```

---

## 📝 **Then Run the Full File**

```bash
psql -d northwind -f sql/02-sales.sql
```

**Should now show all 5 query results with no errors.**

---

## 💡 **Why This Error Happened**

### **PostgreSQL Type System:**

PostgreSQL is very strict about types. `ROUND()` has two versions:

| Function | Input Type | Works With |
|----------|-----------|------------|
| `ROUND(numeric, int)` | numeric | ✅ Works |
| `ROUND(double precision, int)` | double precision | ❌ Doesn't exist! |

**`PERCENTILE_CONT` returns `double precision`**  
**`ROUND(x, n)` with 2 arguments only accepts `numeric`**

**Solution:** Cast with `::numeric` to convert the type.

---

## 📊 **Interesting Insight From Your Data**

### **About the 1998 YoY "Decline":**

Your YoY query shows:
```
1998 | 440623.87 | 617085.20 | -176461.33 | -28.60
```

**This looks bad but it's NOT actually a decline.**

**Why:** The 1998 data only goes through May (5 months vs 12 months in 1997).

**Add this note to your README:**

```markdown
### ⚠️ Data Completeness Note

The Northwind database contains complete data for:
- **1996:** July - December (6 months)
- **1997:** January - December (12 months - complete year)  
- **1998:** January - May (5 months - incomplete year)

**YoY comparisons should account for this.** The apparent 28.6% revenue 
decline in 1998 is misleading - when annualized, 1998 was on track for 
~$1.06M vs $617K in 1997 (72% growth).

**Annualized 1998 Revenue:**
- Jan-May 1998: $440,623
- Monthly average: $88,124
- Projected full year: $1,057,493
- Projected YoY growth: +71.4%
```

**This shows analytical thinking - not just running queries but understanding data limitations!**

---

## 🚀 **After You Fix Query 10**

### **Your Next Steps:**

**1. Commit your working sales file:**
```bash
cd /Users/b/data/projects/analytics-northwind
git add sql/02-sales.sql
git commit -m "Add sales trend queries with monthly, YoY, quarterly, and frequency analysis"
```

**2. Run the remaining SQL files:**
```bash
# Product analysis
psql -d northwind -f sql/03_product_analysis.sql

# Employee performance
psql -d northwind -f sql/04_employee_performance.sql

# Operational metrics
psql -d northwind -f sql/05_operational_metrics.sql
```

**3. Export results:**
```bash
./scripts/export_all_results.sh
```

**4. Commit everything:**
```bash
git add .
git commit -m "Add all SQL query results and exports"
git push
```

---

## ✅ **Summary**

| Query | Status | Action |
|-------|--------|--------|
| Query 6: Monthly Sales | ✅ Working | None needed |
| Query 7: YoY Growth | ✅ Working | Add data completeness note |
| Query 8: Quarterly | ✅ Working | None needed |
| Query 9: Day of Week | ✅ Working | Note B2B = weekdays only |
| Query 10: Order Frequency | ❌ Error | Add `::numeric` cast |

**Fix is one line change. You're almost done with File 2!** 💪