You’re *this* close — this is a classic PostgreSQL type mismatch.

### What’s happening

In Postgres, `ROUND(x, 2)` only works when `x` is a **numeric** type.
Your `SUM(...)` expression is coming out as **double precision** (usually because one of the inputs like `unit_price` or `discount` is `real/double precision`), so Postgres refuses:

> `function round(double precision, integer) does not exist`

### The fix (cast to numeric *before* rounding)

In your query, change this pattern:

```sql
ROUND(SUM(od.unit_price * od.quantity * (1 - od.discount)), 2)
```

to:

```sql
ROUND(SUM(od.unit_price * od.quantity * (1 - od.discount))::numeric, 2)
```

If you want to be extra explicit (and avoid any “float math” weirdness), cast inside the expression:

```sql
ROUND(
  SUM( (od.unit_price::numeric) * od.quantity * (1 - od.discount)::numeric ),
  2
)
```

or(my pick):
```sql
ROUND(
  SUM(
    od.unit_price::numeric
    * od.quantity::numeric
    * (1::numeric - od.discount::numeric)
  ),
  2
) AS total_revenue
```

Same idea for any other `ROUND(AVG(...), 2)` etc. If it errors, just `::numeric` the aggregated value.

---

💡💡 **Why you saw results after the error:** `psql -f` keeps going by default. If you want it to stop on the first error (way nicer for debugging), run:

```bash
psql -d northwind -v ON_ERROR_STOP=1 -f sql/03_products.sql
```

That’ll fail fast and point you right at the first broken line.

If you paste the few lines around your `LINE 8` / the `ROUND(SUM(...))` section, I can tell you the exact cast that fits *your* column types cleanly (especially around `discount`, which is often the culprit).

---
---

Finance people (and finance *systems*) tend to like **determinism** more than elegance. So I’d pick the **“cast inside the expression”** version as the *most defensible*—*but* with one tweak: cast **discount** cleanly as numeric too, and make the `(1 - discount)` part numeric as well.

Why they like it:

* You’re explicitly saying “this is money math, do it in decimal, not floating point.”
* You avoid hidden float behavior (tiny rounding drift) that can show up when you multiply a float discount through millions of rows.
* It telegraphs intentionality: *this query cares about financial precision.*

Here’s the version I’d ship in a finance-y codebase:

```sql
ROUND(
  SUM(
    od.unit_price::numeric
    * od.quantity::numeric
    * (1::numeric - od.discount::numeric)
  ),
  2
) AS total_revenue
```

That said, the **cast-at-the-end** version is perfectly common and readable:

```sql
ROUND(
  SUM(od.unit_price * od.quantity * (1 - od.discount))::numeric,
  2
)
```

When a finance company would prefer *that*:

* They’ve already standardized column types (`unit_price` is `numeric(…)`, `discount` is `numeric(…)`), so the SUM is already numeric.
* They prioritize readability and trust the schema/contracts.

💡💡 My rule of thumb:

* **Analyst / portfolio SQL:** cast at the end (cleaner).
* **Production finance SQL:** cast early (safer, more explicit), *especially* if any input might be float.

Extra nerd note: if `unit_price` is stored as `money` or `numeric(10,2)` and `discount` is float, the “cast early” version prevents discount from pulling the entire expression into floating-point territory. That’s the sort of bug that only shows up when your auditor is already frowning.

