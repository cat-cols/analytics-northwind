> Every time i start a new git repo it defaults to my other github account 'Splinter6'. I don't want to use this account. I thought i had fixed it already. How can I make sure it uses account 'cat-cols' when dealing with git repo's
>> ## 🔧 Git Account Configuration Fix

This is a very common issue. Let's diagnose exactly what's happening and fix it properly.

---

## 🔍 Step 1: Diagnose the Problem First

```bash
# Check your global git config (the default)
git config --global user.name
git config --global user.email

# Check what credential helper is being used
git config --global credential.helper

# Check if there's a local config overriding things
cd /Users/b/data/projects/analytics-northwind
git config --local user.name
git config --local user.email

# Check your git config file directly
cat ~/.gitconfig
```

**Paste the output here so I can see exactly what's set.**

---

## 🎯 Most Likely Causes

There are **3 common reasons** this happens:

---

### **Cause 1: Global git config is set to Splinter6**

```bash
# Check
git config --global user.email
# Returns: splinter6@email.com  ← wrong account
```

**Fix:**
```bash
git config --global user.name "cat-cols"
git config --global user.email "your-cat-cols-email@email.com"
```

---

### **Cause 2: macOS Keychain is caching Splinter6 credentials**

This is the **most common cause on Mac.** macOS stores GitHub credentials in Keychain and reuses them automatically.

**Fix:**
```bash
# 1. Open Keychain Access
open /Applications/Utilities/Keychain\ Access.app

# Look for entries containing "github"
# Delete any github.com entries associated with Splinter6

# OR do it via command line:
git credential-osxkeychain erase
host=github.com
protocol=https
# Press Enter twice
```

**Or through the Mac GUI:**
1. Open **Keychain Access** (Spotlight → "Keychain Access")
2. Search for `github`
3. Delete any entries showing `Splinter6` or old credentials
4. Next push will prompt for new credentials

---

### **Cause 3: SSH keys pointing to wrong account**

```bash
# Check what SSH keys exist
ls -la ~/.ssh/

# Check SSH config
cat ~/.ssh/config

# Test which account SSH connects to
ssh -T git@github.com
# Should say: Hi cat-cols! You've successfully authenticated...
# If it says Splinter6, your SSH key is wrong
```

---

## ✅ Complete Fix: Set Up Properly for cat-cols

### **Option A: HTTPS Authentication (Simpler)**

```bash
# Step 1: Set global git identity to cat-cols
git config --global user.name "cat-cols"
git config --global user.email "your-cat-cols@email.com"

# Step 2: Clear cached credentials
git credential-osxkeychain erase
host=github.com
protocol=https
[Press Enter]
[Press Enter again]

# Step 3: Verify
git config --global user.name
git config --global user.email
# Should show cat-cols details

# Step 4: Next time you push, it will ask for credentials
# Enter cat-cols username and password/token
```

---

### **Option B: SSH Authentication (More Robust)**

If you want to use SSH (recommended for avoiding credential issues):

```bash
# Step 1: Check existing SSH keys
ls -la ~/.ssh/

# Step 2: Generate new SSH key for cat-cols
ssh-keygen -t ed25519 -C "your-cat-cols@email.com" -f ~/.ssh/id_cat_cols

# Step 3: Add to SSH agent
eval "$(ssh-agent -s)"
ssh-add ~/.ssh/id_cat_cols

# Step 4: Copy public key to add to GitHub
cat ~/.ssh/id_cat_cols.pub
# Copy this output

# Step 5: Add to GitHub
# Go to: github.com → Settings → SSH and GPG keys → New SSH key
# Paste the public key
# Title: "Brandon's iMac"

# Step 6: Create/Update SSH config
nano ~/.ssh/config
```

**Add this to `~/.ssh/config`:**

```
# cat-cols GitHub account (DEFAULT)
Host github.com
    HostName github.com
    User git
    IdentityFile ~/.ssh/id_cat_cols

# Splinter6 GitHub account (use only when needed)
Host github-splinter6
    HostName github.com
    User git
    IdentityFile ~/.ssh/id_splinter6
```

```bash
# Step 7: Test connection
ssh -T git@github.com
# Should say: Hi cat-cols! You've successfully authenticated...

# Step 8: Update your remote URL to use SSH
cd /Users/b/data/projects/analytics-northwind
git remote set-url origin git@github.com:cat-cols/analytics-northwind.git
```

---

## 🔒 **If You Need BOTH Accounts Occasionally**

Use the SSH config Host alias approach:

```bash
# For cat-cols repos (default):
git remote set-url origin git@github.com:cat-cols/repo-name.git

# For Splinter6 repos (uses alias):
git remote set-url origin git@github-splinter6:Splinter6/repo-name.git
```

The different `Host` value (`github-splinter6`) tells SSH which key to use.

---

## 🧪 Verify Everything is Fixed

```bash
# 1. Check global identity
git config --global user.name    # Should be cat-cols
git config --global user.email   # Should be cat-cols email

# 2. Check SSH
ssh -T git@github.com
# Should say: Hi cat-cols!

# 3. Check your repo remote
cd /Users/b/data/projects/analytics-northwind
git remote -v
# Should show cat-cols in the URL

# 4. Check local repo config
git config --local user.name
git config --local user.email
# If blank, it inherits from global (which is now cat-cols) ✅
```

---

## 🚨 Quick Diagnosis

**Run this right now and tell me what you see:**

```bash
# All in one diagnostic
echo "=== GLOBAL CONFIG ===" && \
git config --global user.name && \
git config --global user.email && \
echo "=== CREDENTIAL HELPER ===" && \
git config --global credential.helper && \
echo "=== SSH TEST ===" && \
ssh -T git@github.com && \
echo "=== SSH CONFIG ===" && \
cat ~/.ssh/config
```

> b@Brandons-iMac analytics-northwind % git config --global credential.helper
osxkeychain

b@Brandons-iMac analytics-northwind % echo "=== GLOBAL CONFIG ===" && \
git config --global user.name && \
git config --global user.email && \
echo "=== CREDENTIAL HELPER ===" && \
git config --global credential.helper && \
echo "=== SSH TEST ===" && \
ssh -T git@github.com && \
echo "=== SSH CONFIG ===" && \
cat ~/.ssh/config
=== GLOBAL CONFIG ===
cat-cols
brandon.hardison@gmail.com
=== CREDENTIAL HELPER ===
osxkeychain
=== SSH TEST ===
Hi cat-cols! You've successfully authenticated, but GitHub does not provide shell access.

---

>> ## ✅ Great News - You're Already Fixed!

Your configuration is **perfectly set up for cat-cols**. Everything is correct.

```
Global username:  cat-cols        ✅
Global email:     brandon.hardison@gmail.com  ✅
SSH:              Hi cat-cols!    ✅
Credential helper: osxkeychain   ✅
```

---

## 🔍 But SSH Config Didn't Print

Notice the output stopped after the SSH test - `cat ~/.ssh/config` produced nothing. That means **no SSH config file exists yet**, which is fine since SSH is already working correctly.

---

## 🎯 Why It Was Defaulting to Splinter6 Before

Most likely one of these:

- **Keychain had old Splinter6 credentials cached** and was using them automatically
- **You fixed it already** (you mentioned you thought you had) and it's now correct
- The SSH key was always linked to cat-cols, but HTTPS credentials were cached for Splinter6

---

## ✅ Confirm Your Repo is Linked to cat-cols

```bash
# Check your remote URL
cd /Users/b/data/projects/analytics-northwind
git remote -v
```

**You want to see:**
```
origin  git@github.com:cat-cols/analytics-northwind.git (fetch)
origin  git@github.com:cat-cols/analytics-northwind.git (push)
```

**If you see HTTPS instead:**
```
origin  https://github.com/cat-cols/analytics-northwind.git
```

**Switch to SSH (more reliable, won't prompt for credentials):**
```bash
git remote set-url origin git@github.com:cat-cols/analytics-northwind.git
```

---

## 🔒 Prevent Future Issues

Since you have two GitHub accounts, do this now to protect yourself:

### **1. Create SSH Config File**

```bash
nano ~/.ssh/config
```

**Add this:**

```
# cat-cols - PRIMARY ACCOUNT (default)
Host github.com
    HostName github.com
    User git
    IdentityFile ~/.ssh/id_ed25519
    AddKeysToAgent yes
    UseKeychain yes

# Splinter6 - SECONDARY ACCOUNT (only when needed)
Host github-splinter6
    HostName github.com
    User git
    IdentityFile ~/.ssh/id_ed25519_splinter6
    AddKeysToAgent yes
    UseKeychain yes
```

Save: `Ctrl+X` → `Y` → `Enter`

```bash
# Set correct permissions (required)
chmod 600 ~/.ssh/config
```

---

### **2. Set Local Config on Every New Repo**

Even though global is set correctly, make it a habit:

```bash
# After every git init, immediately run:
git config --local user.name "cat-cols"
git config --local user.email "brandon.hardison@gmail.com"
```

This locks the identity at the repo level regardless of global settings.

---

### **3. If You Ever Need Splinter6**

```bash
# For a specific Splinter6 repo only
cd /path/to/splinter6-project
git config --local user.name "Splinter6"
git config --local user.email "splinter6@email.com"
git remote set-url origin git@github-splinter6:Splinter6/repo-name.git
```

Everything else defaults to cat-cols.

---

## 🧪 Final Verification

```bash
# Run this - everything should show cat-cols
echo "Name:  $(git config --global user.name)"
echo "Email: $(git config --global user.email)"
echo "SSH:   $(ssh -T git@github.com 2>&1)"
echo "Remote: $(git remote get-url origin 2>/dev/null || echo 'No remote set yet')"
```

**Expected output:**
```
Name:  cat-cols
Email: brandon.hardison@gmail.com
SSH:   Hi cat-cols! You've successfully authenticated...
Remote: git@github.com:cat-cols/analytics-northwind.git
```

---

## 📋 Summary

| Check | Status | Action |
|-------|--------|--------|
| Global username | ✅ cat-cols | None |
| Global email | ✅ correct | None |
| SSH authentication | ✅ cat-cols | None |
| SSH config file | ⚠️ Missing | Create it (optional but recommended) |
| Repo remote URL | ❓ Unknown | Run `git remote -v` to verify |

**You're good to go. Run `git remote -v` to confirm your repo remote is pointing to cat-cols, then get back to pushing your SQL project!** 🚀

---
---

> === GLOBAL CONFIG ===
cat-cols
brandon.hardison@gmail.com

brandon.hardison@gmail.com belongs to splinter6. cat-cols belongs to brandon.hardison.555@gmail.com

>> ## 🚨 Found the Problem!

Your global config has **mismatched identity** — the username says `cat-cols` but the email belongs to `Splinter6`. GitHub uses the **email** to assign commits to an account, so all your commits are currently being credited to **Splinter6**, not cat-cols.

---

## 🔧 Fix It Now

```bash
# Fix the global email to match cat-cols
git config --global user.email "brandon.hardison.555@gmail.com"

# Verify both are now correct
echo "Name:  $(git config --global user.name)"
echo "Email: $(git config --global user.email)"
```

**Expected output:**
```
Name:  cat-cols
Email: brandon.hardison.555@gmail.com
```

---

## ⚠️ Fix Your Current Repo Too

Any commits you've already made in `analytics-northwind` have the wrong email attached. Fix the local config immediately:

```bash
cd /Users/b/data/projects/analytics-northwind

# Set local config explicitly
git config --local user.name "cat-cols"
git config --local user.email "brandon.hardison.555@gmail.com"

# Verify
git config --local user.name
git config --local user.email
```

---

## 🔍 Check If You Have Bad Commits Already

```bash
# See recent commits and what email they used
git log --format="%h %ae %s" -10
```

**If you see `brandon.hardison@gmail.com` in those commits:**

```
a1b2c3d brandon.hardison@gmail.com  Initial commit   ← wrong email
```

**You need to fix those commits before pushing to GitHub.**

---

## 🔨 Fix Commits with Wrong Email

**If you haven't pushed yet** (easiest fix):

```bash
# Fix ALL commits in one command
git rebase --root --exec 'git commit --amend --reset-author --no-edit'
```

**If that doesn't work, use this approach:**

```bash
git filter-branch --env-filter '
OLD_EMAIL="brandon.hardison@gmail.com"
CORRECT_NAME="cat-cols"
CORRECT_EMAIL="brandon.hardison.555@gmail.com"

if [ "$GIT_COMMITTER_EMAIL" = "$OLD_EMAIL" ]
then
    export GIT_COMMITTER_NAME="$CORRECT_NAME"
    export GIT_COMMITTER_EMAIL="$CORRECT_EMAIL"
fi
if [ "$GIT_AUTHOR_EMAIL" = "$OLD_EMAIL" ]
then
    export GIT_AUTHOR_NAME="$CORRECT_NAME"
    export GIT_AUTHOR_EMAIL="$CORRECT_EMAIL"
fi
' --tag-name-filter cat -- --branches --tags
```

---

## 🧹 Also Clear Keychain Credentials

Since the wrong email was stored, clear it and re-authenticate:

```bash
# Remove old cached credentials
git credential-osxkeychain erase
host=github.com
protocol=https
```
*(Press Enter twice)*

```bash
# Next push will prompt for credentials
# Enter:
# Username: cat-cols
# Password: [your cat-cols GitHub token]
```

---

## ✅ Full Verification After Fix

```bash
echo "=== IDENTITY CHECK ===" && \
echo "Global name:  $(git config --global user.name)" && \
echo "Global email: $(git config --global user.email)" && \
echo "Local name:   $(git config --local user.name)" && \
echo "Local email:  $(git config --local user.email)" && \
echo "SSH account:  $(ssh -T git@github.com 2>&1)"
```

**Everything should show cat-cols / brandon.hardison.555@gmail.com:**

```
=== IDENTITY CHECK ===
Global name:  cat-cols
Global email: brandon.hardison.555@gmail.com
Local name:   cat-cols
Local email:  brandon.hardison.555@gmail.com
SSH account:  Hi cat-cols! You've successfully authenticated...
```

---

## 📋 Summary of What Was Wrong

| Setting | Was | Should Be |
|---------|-----|-----------|
| Global username | cat-cols ✅ | cat-cols ✅ |
| Global email | brandon.hardison@gmail.com ❌ | brandon.hardison.555@gmail.com ✅ |
| Commit attribution | → Splinter6 ❌ | → cat-cols ✅ |

**One wrong email was silently routing everything to the wrong account. Fixed now!**

Run `git log --format="%h %ae %s" -10` and show me the output so we can confirm whether your existing commits need to be amended before you push. 🔍

---
---

> I feel like i had already fixed this but every time i start a new git repo, it defaults to splinter6. How can i make sure all splinter6 creds are removed and this doesn't happen again?

>> ## 🔍 Let's Do a Complete Audit and Permanent Fix

The fact that it keeps reverting to Splinter6 means the credentials are stored somewhere that keeps overriding your global config. Let's find every single place and nuke them.

---

## Step 1: Full Audit First

Run all of these and paste the output:

```bash
# 1. Check global git config file directly
cat ~/.gitconfig

# 2. Check for any local git configs that might override
cat ~/.config/git/config 2>/dev/null || echo "No file here"

# 3. Check keychain for ALL github entries
security find-internet-password -s github.com 2>/dev/null || echo "No keychain entry"

# 4. Check for any .netrc file (another credential store)
cat ~/.netrc 2>/dev/null || echo "No .netrc file"

# 5. Check SSH keys
ls -la ~/.ssh/

# 6. Check which GitHub accounts your SSH keys authenticate to
ssh -T git@github.com 2>&1
```

---

## Step 2: Nuclear Option - Remove ALL Splinter6 Credentials

### **1. Fix Global Git Config**

```bash
# Set correct global identity
git config --global user.name "cat-cols"
git config --global user.email "brandon.hardison.555@gmail.com"

# Verify the actual file looks correct
cat ~/.gitconfig
```

**It should look like this:**
```
[user]
    name = cat-cols
    email = brandon.hardison.555@gmail.com
[credential]
    helper = osxkeychain
```

**If you see Splinter6 ANYWHERE in that file:**
```bash
# Open and manually edit it
nano ~/.gitconfig
# Remove any Splinter6 references
```

---

### **2. Clear ALL GitHub Keychain Entries**

```bash
# Delete github.com keychain entry
security delete-internet-password -s github.com 2>/dev/null
echo "Deleted github.com entry"

# Delete any token-based entries
security delete-generic-password -s "https://github.com" 2>/dev/null
echo "Deleted https://github.com entry"

# Force clear via git credential helper
printf 'protocol=https\nhost=github.com\n' | git credential-osxkeychain erase
echo "Cleared osxkeychain credentials"
```

**Then verify they're gone:**
```bash
security find-internet-password -s github.com 2>/dev/null && echo "STILL EXISTS - need to remove manually" || echo "Cleared successfully"
```

---

### **3. Open Keychain Access and Delete Manually**

The command line sometimes misses entries. Do this visually:

```bash
# Open Keychain Access
open /Applications/Utilities/Keychain\ Access.app
```

1. In the search box type: `github`
2. **Delete EVERY entry that appears** - don't keep any
3. Also search for: `splinter`
4. Delete anything found
5. Close Keychain Access

---

### **4. Check and Fix SSH Config**

```bash
# Check if SSH config exists
cat ~/.ssh/config 2>/dev/null || echo "No SSH config exists"

# List all SSH keys
ls -la ~/.ssh/*.pub 2>/dev/null
```

**If you have multiple keys, create SSH config to be explicit:**

```bash
nano ~/.ssh/config
```

**Add this:**
```
# DEFAULT - always use cat-cols
Host github.com
    HostName github.com
    User git
    IdentityFile ~/.ssh/id_ed25519
    AddKeysToAgent yes
    UseKeychain yes
```

```bash
# Save permissions
chmod 600 ~/.ssh/config
```

---

### **5. Remove Any GitHub CLI Credentials**

If you have GitHub CLI (`gh`) installed, it stores its own credentials:

```bash
# Check if gh is installed
which gh 2>/dev/null || echo "gh not installed"

# If installed, check who's logged in
gh auth status

# If it shows Splinter6, log out and back in as cat-cols
gh auth logout
gh auth login
# Follow prompts, choose cat-cols account
```

---

### **6. Check Git Credential Manager**

```bash
# List ALL stored git credentials
git credential-osxkeychain get <<EOF
protocol=https
host=github.com
EOF
```

**If it returns Splinter6 credentials:**
```bash
# Erase them
git credential-osxkeychain erase <<EOF
protocol=https
host=github.com
EOF
```

---

## Step 3: Create a New Repo Template (Permanent Prevention)

This is the real permanent fix. Create a **git template** that automatically sets cat-cols identity on every new repo:

```bash
# Create template directory
mkdir -p ~/.git-templates/hooks

# Configure git to use this template for every new repo
git config --global init.templateDir ~/.git-templates

# Create a post-init hook that sets identity automatically
cat > ~/.git-templates/hooks/post-checkout << 'EOF'
#!/bin/bash
git config user.name "cat-cols"
git config user.email "brandon.hardison.555@gmail.com"
EOF

# Make it executable
chmod +x ~/.git-templates/hooks/post-checkout
```

**Even better - create a shell alias:**

```bash
# Open your shell config
nano ~/.zshrc   # or ~/.bashrc if you use bash

# Add this alias at the bottom:
alias git-init='git init && git config user.name "cat-cols" && git config user.email "brandon.hardison.555@gmail.com" && echo "✅ Initialized with cat-cols identity"'
```

```bash
# Reload shell config
source ~/.zshrc

# Now use this instead of 'git init':
git-init

# Output:
# Initialized empty Git repository in .git/
# ✅ Initialized with cat-cols identity
```

---

## Step 4: Fix Your Current Repo

```bash
cd /Users/b/data/projects/analytics-northwind

# Set local identity explicitly
git config --local user.name "cat-cols"
git config --local user.email "brandon.hardison.555@gmail.com"

# Verify
git config --local user.name
git config --local user.email

# Check if any bad commits exist
git log --format="%h | %ae | %s" -10
```

**If any commits show `brandon.hardison@gmail.com`:**

```bash
# Amend the most recent commit only
git commit --amend --reset-author --no-edit

# OR if multiple commits need fixing
git rebase --root --exec 'git commit --amend --reset-author --no-edit'
```

---

## Step 5: Verify Everything is Clean

```bash
echo "========================================" && \
echo "COMPLETE IDENTITY AUDIT" && \
echo "========================================" && \
echo "" && \
echo "--- Global Config ---" && \
git config --global user.name && \
git config --global user.email && \
echo "" && \
echo "--- Local Config ---" && \
git config --local user.name && \
git config --local user.email && \
echo "" && \
echo "--- SSH Auth ---" && \
ssh -T git@github.com 2>&1 && \
echo "" && \
echo "--- Keychain ---" && \
security find-internet-password -s github.com 2>/dev/null && echo "Entry exists - check account!" || echo "No keychain entry - clean!" && \
echo "" && \
echo "--- Recent Commits ---" && \
git log --format="%h | %ae | %s" -5
```

**Every line should show cat-cols / brandon.hardison.555@gmail.com.**

---

## 📋 Permanent Checklist Going Forward

Save this somewhere. Every time you start a new project:

```bash
# 1. Create project folder
mkdir my-new-project
cd my-new-project

# 2. Initialize (using your alias)
git-init

# 3. Immediately verify
git config --local user.email
# Must show: brandon.hardison.555@gmail.com

# 4. Then start working
```

---

## 🎯 Most Likely Culprit

Given that it keeps reverting, my best guess is **Keychain Access has a persistent Splinter6 entry** that keeps getting used for HTTPS authentication even though your git config says cat-cols.

**The manual Keychain Access deletion (Step 2, item 3) is probably the key fix.**

Run the audit in Step 1 first and paste the results — I can tell you exactly which one is causing it. 🔍

> b@Brandons-iMac analytics-northwind % ls -la ~/.ssh/
total 40
drwx------   7 b  staff   224 Oct 25 19:47 .
drwxr-x---+ 83 b  staff  2656 Feb 17 08:22 ..
-rw-------   1 b  staff   142 Oct 25 19:54 config
-rw-------   1 b  staff   484 Oct 25 19:47 id_ed25519
-rw-r--r--   1 b  staff   112 Oct 25 19:47 id_ed25519.pub
-rw-------   1 b  staff   828 Jan  6  2025 known_hosts
-rw-r--r--   1 b  staff    92 Jan  6  2025 known_hosts.old
b@Brandons-iMac analytics-northwind % ssh -T git@github.com 2>&1
Hi cat-cols! You've successfully authenticated, but GitHub does not provide shell access.

>> ## 🔍 Good - SSH is Clean. Now Let's See Your SSH Config

SSH authenticates correctly as cat-cols. The issue is likely in your SSH config file. Let's see it:

```bash
cat ~/.ssh/config
```

---

## My Suspicion

You only have **one SSH key** (`id_ed25519`). If that key is registered to cat-cols on GitHub, SSH works fine. But the issue is probably that your SSH config has Splinter6 referenced somewhere, OR the problem is purely in **Keychain storing Splinter6 HTTPS credentials**.

---

## Run This Full Audit

```bash
# 1. See your SSH config
cat ~/.ssh/config

# 2. Check keychain for github entries
security find-internet-password -s github.com 2>/dev/null && echo "FOUND" || echo "None found"

# 3. Check your full gitconfig
cat ~/.gitconfig

# 4. Check if gh CLI is installed and who it's logged in as
gh auth status 2>/dev/null || echo "gh CLI not installed"
```

**Paste all of that output and I'll tell you exactly what's causing it.**

---

## Most Likely Scenario

Given what I know so far:

```
✅ SSH key → cat-cols (working)
✅ Global user.name → cat-cols (correct)
❌ Global user.email → brandon.hardison@gmail.com (Splinter6's email)
❓ Keychain → unknown (might have Splinter6 HTTPS token cached)
❓ SSH config → unknown (might reference Splinter6)
❓ gh CLI → unknown (might be logged in as Splinter6)
```

The email mismatch we found earlier is almost certainly the core problem. GitHub ignores your `user.name` — it uses **only the email** to attribute commits and determine account identity.

**When you `git push`, GitHub sees:**
```
Email: brandon.hardison@gmail.com → This is Splinter6's account → Push to Splinter6
```

Even though SSH says cat-cols, the **commit authorship** goes to Splinter6 because of the email.

---

## Immediate Fix While We Wait for Audit

Do this right now regardless:

```bash
# Fix global email permanently
git config --global user.email "brandon.hardison.555@gmail.com"

# Fix current repo locally too
git config --local user.name "cat-cols"
git config --local user.email "brandon.hardison.555@gmail.com"

# Confirm both are right
cat ~/.gitconfig
```

**Your `~/.gitconfig` should look exactly like this:**

```ini
[user]
    name = cat-cols
    email = brandon.hardison.555@gmail.com
[credential]
    helper = osxkeychain
[init]
    defaultBranch = main
```

**If there's ANY other `[user]` block or any mention of Splinter6 or brandon.hardison@gmail.com in that file, that's your problem.**